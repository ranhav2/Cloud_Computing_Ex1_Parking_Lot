import json
import boto3
import uuid
import time

def lambda_handler(event, context):
    ticketId = event.get('queryStringParameters',{}).get('ticketId','undefined')

    if(ticketId == 'undefined'):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'ticketId is undefined'})
        }
    
    dynamodb = boto3.client('dynamodb')
    data = dynamodb.get_item(TableName='Lots', Key={'ticketId':{'S':ticketId}})
    item = data.get('Item')

    if(item is None):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'Invalid ticketId'})
        }
        
    carEntranceTime = float(item.get('carEntranceTime').get('N'))
    plate = (item.get('plate').get('S'))
    parkingLot = (item.get('parkingLot').get('S'))

    current_time = time.time()
    parked_time = current_time - carEntranceTime

    totalTime = parked_time / 60
    price = int(totalTime / 15) * 2.5

    dynamodb.delete_item(TableName='Lots', Key={'ticketId':{'S':ticketId}})
    
    return {
        'statusCode': 200,
        'body': json.dumps({'plate': plate,'totalTime': totalTime,'parkingLot': parkingLot,'price': price})
    }