# debug
# set -o xtrace

REGION=$(aws ec2 describe-availability-zones | jq -r .AvailabilityZones[0].RegionName)
AWS_ACCOUNT=$(aws sts get-caller-identity  | jq -r .Account)
RUN_ID=$(date +'%N')
AWS_ROLE="lambda-role-ddb"
FUNC_NAME1="parking-entry"
API_NAME1="entry"
FUNC_NAME2="parking-exit"
API_NAME2="exit"

echo "Creating role $AWS_ROLE..."
aws iam create-role --role-name $AWS_ROLE --assume-role-policy-document file://trust-policy.json

echo "Allowing writes to CloudWatch logs..."
aws iam attach-role-policy --role-name $AWS_ROLE  \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaDynamoDBExecutionRole

aws iam put-role-policy --role-name $AWS_ROLE \
    --policy-name parking \
    --policy-document  file://parking.json

echo "Creating dynamodb table..."
aws dynamodb create-table \
    --table-name Lots \
    --attribute-definitions \
        AttributeName=ticketId,AttributeType=S \
    --key-schema \
        AttributeName=ticketId,KeyType=HASH \
    --provisioned-throughput \
        ReadCapacityUnits=10,WriteCapacityUnits=5

echo "Packaging code..."
zip lambda_entry.zip entry.py
zip lambda_exit.zip exit.py

echo "Wait for role creation"

aws iam wait role-exists --role-name $AWS_ROLE
aws iam get-role --role-name $AWS_ROLE
ARN_ROLE=$(aws iam get-role --role-name $AWS_ROLE | jq -r .Role.Arn)

echo "Workaround consistency rules in AWS roles after creation... (sleep 10)"
sleep 10

echo "Creating function $FUNC_NAME1..."
aws lambda create-function --function-name $FUNC_NAME1 \
    --zip-file fileb://lambda_entry.zip --handler entry.lambda_handler \
    --runtime python3.8 --role $ARN_ROLE


FUNC_ARN1=$(aws lambda get-function --function-name $FUNC_NAME1 | jq -r .Configuration.FunctionArn)

echo "Creating function $FUNC_NAME2..."
aws lambda create-function --function-name $FUNC_NAME2 \
    --zip-file fileb://lambda_exit.zip --handler exit.lambda_handler \
    --runtime python3.8 --role $ARN_ROLE


FUNC_ARN2=$(aws lambda get-function --function-name $FUNC_NAME2 | jq -r .Configuration.FunctionArn)

API_CREATED=$(aws apigatewayv2 create-api --name $API_NAME1 --protocol-type HTTP --target $FUNC_ARN1)
API_ID=$(echo $API_CREATED | jq -r .ApiId)
API_ENDPOINT1=$(echo $API_CREATED | jq -r .ApiEndpoint)


STMT_ID=$(uuidgen)

aws lambda add-permission --function-name $FUNC_NAME1 \
    --statement-id $STMT_ID --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:$REGION:$AWS_ACCOUNT:$API_ID/*"


API_CREATED=$(aws apigatewayv2 create-api --name $API_NAME2 --protocol-type HTTP --target $FUNC_ARN2)
API_ID=$(echo $API_CREATED | jq -r .ApiId)
API_ENDPOINT2=$(echo $API_CREATED | jq -r .ApiEndpoint)


STMT_ID=$(uuidgen)

aws lambda add-permission --function-name $FUNC_NAME2 \
    --statement-id $STMT_ID --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:$REGION:$AWS_ACCOUNT:$API_ID/*"

echo "Entry: " $API_ENDPOINT1
echo "Exit: " $API_ENDPOINT2





