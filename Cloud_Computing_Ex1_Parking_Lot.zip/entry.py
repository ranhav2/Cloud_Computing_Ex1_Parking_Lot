import json
import boto3
import uuid
import time
import re


def lambda_handler(event, context):
    plate = event.get('queryStringParameters',{}).get('plate','undefined')
    parkingLot = event.get('queryStringParameters',{}).get('parkingLot','undefined')
    dynamodb = boto3.client('dynamodb')


    if(plate == 'undefined'):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'plate is undefined'})
        }
    is_plate = re.match(r"\d\d\d-\d\d\d-\d\d\d", str(plate))
    if(is_plate is None):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'Invalid plate number'})
        }
    
    if(parkingLot == 'undefined'):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'parkingLot is undefined'})
        }
        
    ticketId = str(uuid.uuid1())
    carEntranceTime = str(time.time())

    dynamodb.put_item(
        TableName='Lots',
        Item={
                'ticketId':{'S': ticketId},
                'carEntranceTime':{'N':carEntranceTime},
                'plate':{'S':plate},
                'parkingLot':{'S':parkingLot}
        }
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps({'ticketId': ticketId})
    }